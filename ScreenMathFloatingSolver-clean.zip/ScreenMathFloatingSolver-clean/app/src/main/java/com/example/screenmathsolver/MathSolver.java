package com.example.screenmathsolver;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MathSolver {
    private static final DecimalFormat DF = new DecimalFormat("0.##########");

    public static String solveText(String raw) {
        String text = raw.replace('×','*').replace('÷','/').replace('−','-').replace('–','-').replace('²','^2').replace('³','^3');
        ArrayList<String> out = new ArrayList<>();
        // Percent-of questions
        Matcher pm = Pattern.compile("(?i)([-+]?\\d+(?:\\.\\d+)?)\\s*%\\s*(?:of|\\*)\\s*([-+]?\\d+(?:\\.\\d+)?)").matcher(text);
        while(pm.find()) {
            double a=Double.parseDouble(pm.group(1)), b=Double.parseDouble(pm.group(2));
            out.add(pm.group(0)+" = "+DF.format(a*b/100.0));
        }
        // x^2 + bx + c = 0
        Matcher qm = Pattern.compile("(?i)([-+]?\\d*\\.?\\d*)\\s*\\^?2\\s*([+-]\\s*\\d*\\.?\\d*)\\s*x\\s*([+-]\\s*\\d+(?:\\.\\d+)?)\\s*=\\s*0").matcher(text.replace(" ",""));
        while(qm.find()) {
            double a=parseCoeff(qm.group(1),1), b=parseCoeff(qm.group(2),0), c=Double.parseDouble(qm.group(3).replace("+",""));
            double d=b*b-4*a*c;
            if(d<0) out.add(qm.group(0)+" -> no real roots");
            else { double r1=(-b+Math.sqrt(d))/(2*a), r2=(-b-Math.sqrt(d))/(2*a); out.add(qm.group(0)+" -> x="+DF.format(r1)+(Math.abs(r1-r2)>1e-10?", "+DF.format(r2):"")); }
        }
        // ax+b=c
        Matcher lm = Pattern.compile("(?i)^([+-]?\\d*\\.?\\d*)x([+-]\\d+(?:\\.\\d+)?)=([+-]?\\d+(?:\\.\\d+)?)$").matcher(text.trim().replace(" ",""));
        if(lm.find()) {
            double a=parseCoeff(lm.group(1),1), b=Double.parseDouble(lm.group(2)), c=Double.parseDouble(lm.group(3));
            out.add("x = "+DF.format((c-b)/a));
        }
        // Simple arithmetic: numbers and operators only
        String expr=text.trim().replace(" ","");
        if(expr.matches("[0-9.()+\\-*/%^]+")) {
            try { out.add(expr+" = "+DF.format(eval(expr))); } catch(Exception ignored) {}
        }
        if(out.isEmpty()) return "No supported math found";
        return String.join("\\n", out);
    }

    private static double parseCoeff(String s,double defaultVal){
        if(s==null||s.isEmpty()||s.equals("+")) return defaultVal;
        if(s.equals("-")) return -defaultVal;
        return Double.parseDouble(s);
    }

    // Small expression parser (recursive descent)
    private static double eval(String s){ return new P(s).parse(); }
    private static class P {
        String s; int p=0; P(String s){this.s=s;}
        double parse(){double v=expr(); if(p!=s.length()) throw new IllegalArgumentException(); return v;}
        double expr(){double v=term(); while(p<s.length()){char c=s.charAt(p); if(c=='+'||c=='-'){p++; double r=term(); v=c=='+'?v+r:v-r;} else break;} return v;}
        double term(){double v=pow(); while(p<s.length()){char c=s.charAt(p); if(c=='*'||c=='/'||c=='%'){p++; double r=pow(); v=c=='*'?v*r:c=='/'?v/r:v%r;} else break;} return v;}
        double pow(){double v=unary(); if(p<s.length()&&s.charAt(p)=='^'){p++; v=Math.pow(v,pow());} return v;}
        double unary(){if(p<s.length()&&(s.charAt(p)=='+'||s.charAt(p)=='-')){char c=s.charAt(p++); return c=='-'?-unary():unary();} if(p<s.length()&&s.charAt(p)=='('){p++; double v=expr(); if(p>=s.length()||s.charAt(p++)!=')') throw new IllegalArgumentException(); return v;} int st=p; while(p<s.length()&&(Character.isDigit(s.charAt(p))||s.charAt(p)=='.'))p++; if(st==p)throw new IllegalArgumentException(); return Double.parseDouble(s.substring(st,p));}
    }
}
